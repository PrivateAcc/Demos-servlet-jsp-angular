package com.cg.login.dao;

import java.sql.Connection;

import com.cg.login.bean.LoginBean;
import com.cg.login.exception.LoginException;
import com.cg.login.util.DBConnection;


public class LoginDaoImpl implements ILogindao {

	@Override
	public boolean verifyLogin(LoginBean loginBean) throws LoginException {
		boolean result=false;
		Connection connection =DBConnection.getConnection("insert into table product values(empid");
		
		return result;
	}

}
