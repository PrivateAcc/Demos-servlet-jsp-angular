package com.cg.login.exception;

public class LoginException extends Exception {
		String MESSAGE1="exception";

}
