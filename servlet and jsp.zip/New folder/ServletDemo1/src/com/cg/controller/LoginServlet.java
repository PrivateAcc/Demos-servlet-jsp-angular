package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LoginServlet() {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException {
         System.out.println("in init");
		
	}

	public void destroy() {
		System.out.println("in destroy");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("to get");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("uname");
		String password=request.getParameter("pwd");
	
		
		
		response.setContentType("text/html");

		PrintWriter pw=response.getWriter();
		
		
		if(username.equals("admin")&& password.equals("admin123")) {
			pw.println("<html><body>"
					+ "<h3>"
					+ "Welcome"+username+"!"
					+"<br/>"
					+ "Todays date: "+LocalDate.now()
					+"</h3>"
					+"</body></html>");
			
			
			
		}else {
			pw.println("<html><body>"
					+ "<h3>"
					+ "enter correct username and password <br/>"
					+ "<a href='index.html'> go to login page </a>"
					+"</h3>"
					+"</body></html>");
			
		}
		
		
		
		
		
		//String []cities =request.get
		//doGet(request, response);
	}

}
