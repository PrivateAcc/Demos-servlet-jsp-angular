var employee = {
    firstName: "jaya",
    lastName: "ghosh",
    age: 22,
    sal: true,
    address: null
};
console.log("name is" + employee.firstName + " " + employee.lastName + "  Age is" + employee.age + " salary is " + employee.sal + " address is " + employee.address);
