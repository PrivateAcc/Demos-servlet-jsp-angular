class Example3{

constructor()
{
console.log("hello");
}
constructor(id: number,name:string,age:number){
this.id=id;
this.name=name;
this.age=age;
}
doGet(){
var i;
for( i=0;i<5;i++){
console.log(i);
}
}

}
let obj=new Example3();
obj.doGet();
let obj1=new Example3(123,"jaya",22);
