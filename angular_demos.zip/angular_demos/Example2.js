var Example2 = /** @class */ (function () {
    function Example2() {
        console.log("hello");
    }
    Example2.prototype.doGet = function () {
        var i;
        for (i = 0; i < 5; i++) {
            console.log(i);
        }
    };
    return Example2;
}());
var obj = new Example2();
obj.doGet();
