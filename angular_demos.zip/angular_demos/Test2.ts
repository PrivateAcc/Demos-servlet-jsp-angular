import {Test} from "./Test1";
let t:Test={
name:"jaya",
age:20
}
console.log(t.age);
console.log(t.name);



