function doGet(){
let i;
for( i=0;i<5;i++){
console.log(i);
}
//console.log("finally"+i);
}


doGet();