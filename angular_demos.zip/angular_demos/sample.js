console.log(x);
var x = 5;
console.log(x);
