interface Employee{
firstName:string;
lastName:string;
age:number;
sal:boolean;
address:null;
}

let employee:Employee={
firstName:"jaya",
lastName:"ghosh",
age:22,
sal:true,
address:null
}
console.log("name is"+employee.firstName+" "+employee.lastName+"  Age is"+employee.age+" salary is "+employee.sal+" address is "+employee.address);
