function Sample() {
    var name = "Typescript";
    var greeting = "hello," + name + "! your name has \n               " + name.length + " characters";
}
