"use strict";
exports.__esModule = true;
var Test = /** @class */ (function () {
    function Test() {
    }
    Test.prototype.add = function () {
    };
    return Test;
}());
exports.Test = Test;
