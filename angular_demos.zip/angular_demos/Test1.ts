export class Test{
name:string;
age:number;

private add(){

}
constructor(){

}

}