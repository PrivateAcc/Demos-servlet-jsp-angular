var Example3 = /** @class */ (function () {
    function Example3() {
        console.log("hello");
    }
    Example3.prototype.doGet = function () {
        var i;
        for (i = 0; i < 5; i++) {
            console.log(i);
        }
    };
    return Example3;
}());
var obj = new Example2();
obj.doGet();
