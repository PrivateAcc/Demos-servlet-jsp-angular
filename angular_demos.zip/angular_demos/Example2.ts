class Example2{

constructor()
{
console.log("hello");
}
doGet(){
var i;
for( i=0;i<5;i++){
console.log(i);
}
}

}
let obj=new Example2();

