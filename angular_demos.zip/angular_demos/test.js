var Test = /** @class */ (function () {
    function Test() {
    }
    return Test;
}());
