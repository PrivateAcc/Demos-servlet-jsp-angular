console.log(x);
let x=5;
console.log(x);