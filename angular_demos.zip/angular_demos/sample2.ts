function sumAll(...num:number[]){
let sum:number=0;
for(let data of num){
sum=data+sum;
console.log("addition is"+data);
}
console.log("sum is"+sum);
}
sumAll(2,7,4,7,8,9,6,5);
