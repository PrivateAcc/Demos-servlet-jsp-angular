function Sample() {
var name="Typescript";
var greeting=`hello,${name}! your name has 
               ${name.length} characters`;
			  
}