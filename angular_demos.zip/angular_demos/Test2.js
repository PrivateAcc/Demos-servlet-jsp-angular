"use strict";
exports.__esModule = true;
var t = {
    name: "jaya",
    age: 20
};
console.log(t.age);
console.log(t.name);
